<?php
ini_set('display_errors', '1');//To display php errors
require('PHPExcel/PHPExcel.php');//Enter path of PHPExcel library
require('PHPExcel/PHPExcel/IOFactory.php');

/**
 * Establish DB Connection
 */
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "excel";
 $con= mysqli_connect($servername,$username,$password,$dbname);
 if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}

/**
 * Download the zip file and extract it locally
 */
if (class_exists("ZipArchive")) {
    
    /**
     * The url below, ideally should be dynamic. Since we don't have exact path location on the server to download the file, so hardcoding it.
     * @var string
     */
    $url  =  'https://www.ccilindia.com/Research/Statistics/Lists/DailyDataForInfoVendors/Attachments/3091/DFIV_09_07_2021.zip' ;
    $file_name  =   basename($url);
    $cont = file_get_contents($url);
    
    if(file_put_contents( $file_name,file_get_contents($url))){
        echo "File downloaded successfully!"; 
    }else{
        echo "File downloading failed!"; 
    }
   $zip = new ZipArchive;
  
    if ($zip->open($file_name) === true) {
        $zip->extractTo("upload");
        $zip->close();
    } 

    $file = "upload/CCIL01.xls";
    try {
    $reader = PHPExcel_IOFactory::createReaderForFile($file);
   $obj = $reader->load($file);
   $sheet = $obj->getSheet('0');

       
   } catch(Exception $e) {
    die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
}

  $gethighestrow = $sheet->getHighestRow() ;//get row count
  $highestColumn      = $sheet->getHighestColumn(); 
  $highestColumnIndex = PHPExcel_Cell::columnIndexFromString($highestColumn); //get column count


    

    /**
     * Query to import data to the database
     */

     $sql = "CREATE TABLE data (
    `date` TEXT
    )";
    mysqli_query($con, $sql);//Create a date column 

     for($row = 2; $row<=$gethighestrow ; $row++ ) {// Iterate through rows in the first column
        $rowValue = $sheet->getCellByColumnAndRow(0, $row)->getValue();

        if($rowValue === NULL || $rowValue === '') { //if cell is empty, delete the xls and zip file. This case should not arise if there are no empty cells in excel sheet, yet in case of fallback.
            deleteFiles($file_name);
            die();
            } else {
                mysqli_query($con,"ALTER TABLE `data` ADD `$rowValue`  TEXT"); //Add the row in excel as column in db.
            }

            for($col = 1; $col<=$highestColumnIndex ; $col++) {// Iterate through columns in the first row
            $dateValue = $sheet->getCellByColumnAndRow($col, 1)->getValue();
            $date= PHPExcel_Shared_Date::ExcelToPHPObject($dateValue)->format('d-m-Y');
           
            $colValue =  $sheet->getCellByColumnAndRow($col, $row)->getValue();
            

                /**
                 * Check for same value of date in rows. If exists update that row or else insert a new row
                 */
             $dateExists = mysqli_query($con, "SELECT count(*)
     as 'date_count' from `data` where `date`='$date'")->fetch_assoc()['date_count'];

                
                if($dateExists != "0"){ 
                    $mysqli_update = "UPDATE `data` set `$rowValue` ='$colValue' where `date`='$date'";
                             mysqli_query($con, $mysqli_update) OR die(mysqli_error($con));

                } else {
                    $mysqli_insert = "INSERT INTO `data` (`date`, `$rowValue`) Values
                             ('$date','$colValue')" ;
                             mysqli_query($con, $mysqli_insert) OR die(mysqli_error($con));
                }
           
            }
     }

    } else {
        echo "File connot be extracted. Enable Zip Archive function";
    }


    /**
     * Deletes all files and folders 
     * param string $file_name        The name of zip file to be deleted
     * @return void
     */
    function deleteFiles($file_name) {
        $files = glob('upload/*'); //All files inside upload folder
            foreach($files as $file){ // iterate files
                unlink($file); // delete file
            }
            unlink($file_name); //Delete the zip file
            echo "Import successful";
    }



?>